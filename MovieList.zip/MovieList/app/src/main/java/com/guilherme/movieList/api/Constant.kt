package com.guilherme.movieList.api

const val URL = "https://api.themoviedb.org/3/"
const val API_KEY = "1f54bd990f1cdfb230adb312546d765d"
const val DEFAULT_LANGUAGE = "pt-BR"
const val DEFAULT_REGION = "BR"